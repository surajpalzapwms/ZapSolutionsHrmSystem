import dns from "dns";

// Force reliable DNS resolvers so mongodb+srv:// SRV lookups don't fail
// on networks/ISPs whose default DNS doesn't handle SRV records properly
dns.setServers(["8.8.8.8", "1.1.1.1"]);

import "dotenv/config";
import express from "express";
import cors from "cors";
import morgan from "morgan";
import connectDB from "./utils/db.js";
import authRoutes from "./routes/authRoutes.js";
import payrollRoutes from "./routes/payrollRoutes.js";
import expenseRoutes from "./routes/expenseRoutes.js";
import attendanceRoutes from "./routes/attendance.js";
import holidayRoutes from "./routes/holiday.js";
import saturdayHolidayRoutes from "./routes/saturdayHoliday.js";
import staffRoutes from "./routes/staffRoutes.js";
import advanceRoutes from "./routes/advanceRoutes.js";
import staffBasicPayrollRoutes from "./routes/staffBasicPayrollRoutes.js";
import expenseCategoryRoutes from "./routes/expenseCategoryRoutes.js";
import officeExpenseRoutes from "./routes/officeExpenseRoutes.js";
import { errorHandler } from "./middleware/errorHandler.js";
import leaveAttendanceRoutes from "./routes/leave.js";

const app = express();

// Middleware
// Strip trailing slashes so "http://localhost:5173/" and "http://localhost:5173"
// are treated as the same origin (a common source of CORS rejections).
const stripTrailingSlash = (url) => url.trim().replace(/\/+$/, "");

const allowedOrigins = (process.env.FRONTEND_URL || "http://localhost:5173")
  .split(",")
  .map(stripTrailingSlash);

app.use(
  cors({
    origin: (origin, callback) => {
      // allow non-browser tools (curl/Postman) that send no Origin header
      if (!origin) return callback(null, true);

      const normalizedOrigin = stripTrailingSlash(origin);

      if (allowedOrigins.includes(normalizedOrigin)) {
        callback(null, true);
      } else {
        // Log exactly what was rejected vs what's allowed, so a mismatched
        // port/host/trailing-slash in FRONTEND_URL is easy to spot.
        console.warn(
          `❌ CORS rejected origin "${origin}". Allowed origins: ${allowedOrigins.join(", ")}. ` +
            `Check FRONTEND_URL in your backend .env file.`,
        );
        callback(null, false);
      }
    },
    credentials: true,
  }),
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/hrm/payroll", payrollRoutes);
app.use("/api/expenses", expenseRoutes);
app.use("/api/hrm/attendance", attendanceRoutes);
app.use("/api/hrm/holidays", holidayRoutes);
app.use("/api/hrm/saturday-holidays", saturdayHolidayRoutes);
app.use("/api/hrm/leaves", leaveAttendanceRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/hrm/advances", advanceRoutes);
app.use("/api/hrm/staff-basic-payrolls", staffBasicPayrollRoutes);
app.use("/api/hrm/expense-categories", expenseCategoryRoutes);
app.use("/api/hrm/office-expenses", officeExpenseRoutes);

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "ok",
    service: "hrm-backend",
    timestamp: new Date().toISOString(),
  });
});

// Error handler
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

if (!MONGO_URI) {
  console.error("❌ Missing MONGO_URI in .env");
  process.exit(1);
}

async function startServer(retries = 3, delayMs = 3000) {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      await connectDB(MONGO_URI);
      app.listen(PORT, () => {
        console.log(`🚀 HRM backend running on port ${PORT}`);
        console.log(`📊 Environment: ${process.env.NODE_ENV}`);
        console.log(`🌐 Allowed CORS origins: ${allowedOrigins.join(", ")}`);
      });
      return;
    } catch (err) {
      console.error(`❌ MongoDB connection attempt ${attempt} failed:`, err.message);
      if (attempt === retries) {
        console.error("❌ Failed to start server after all retries:", err);
        process.exit(1);
      }
      console.log(`⏳ Retrying in ${delayMs / 1000}s...`);
      await new Promise((resolve) => setTimeout(resolve, delayMs));
    }
  }
}

startServer();