import Staff from "../models/Staff.js";
import Resignation from "../models/Resignation.js";

async function staffForRequest(req) {
  const email = req.user?.email?.toLowerCase().trim();
  return email ? Staff.findOne({ email }).lean() : null;
}

// GET /me — the caller's current (non-withdrawn) resignation, if any.
export const getMyResignation = async (req, res) => {
  try {
    const staff = await staffForRequest(req);
    if (!staff) return res.json({ success: true, data: null });
    const resignation = await Resignation.findOne({
      userId: staff._id,
      status: { $ne: "withdrawn" },
    })
      .sort({ createdAt: -1 })
      .lean();
    res.json({ success: true, data: resignation || null });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error: " + error.message });
  }
};

// POST /me — submit a resignation. Blocks a second active one.
export const submitResignation = async (req, res) => {
  try {
    const staff = await staffForRequest(req);
    if (!staff) {
      return res.status(404).json({
        success: false,
        message: "No staff profile is linked to your account yet. Contact your admin.",
      });
    }
    const { lastWorkingDay, reason, noticePeriodDays } = req.body;
    if (!lastWorkingDay || !reason) {
      return res.status(400).json({ success: false, message: "Last working day and reason are required" });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(lastWorkingDay)) {
      return res.status(400).json({ success: false, message: "Invalid date. Use YYYY-MM-DD" });
    }
    const active = await Resignation.findOne({
      userId: staff._id,
      status: { $in: ["pending", "approved"] },
    });
    if (active) {
      return res.status(400).json({ success: false, message: "You already have an active resignation request." });
    }
    const resignation = await Resignation.create({
      userId: staff._id,
      lastWorkingDay: new Date(`${lastWorkingDay}T00:00:00.000Z`),
      reason,
      noticePeriodDays: Number(noticePeriodDays) || 60,
      status: "pending",
    });
    res.status(201).json({ success: true, message: "Resignation submitted.", data: resignation });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error: " + error.message });
  }
};

// DELETE /me — withdraw the caller's pending resignation.
export const withdrawResignation = async (req, res) => {
  try {
    const staff = await staffForRequest(req);
    if (!staff) return res.status(404).json({ success: false, message: "No staff profile linked." });
    const resignation = await Resignation.findOne({ userId: staff._id, status: "pending" }).sort({ createdAt: -1 });
    if (!resignation) {
      return res.status(404).json({ success: false, message: "No pending resignation to withdraw." });
    }
    resignation.status = "withdrawn";
    await resignation.save();
    res.json({ success: true, message: "Resignation withdrawn.", data: resignation });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error: " + error.message });
  }
};