import express from "express";
import { protect } from "../middleware/auth.js";
import { getMyResignation, submitResignation, withdrawResignation } from "../controllers/resignation.js";

const router = express.Router();
router.get("/me", protect, getMyResignation);
router.post("/me", protect, submitResignation);
router.delete("/me", protect, withdrawResignation);
export default router;